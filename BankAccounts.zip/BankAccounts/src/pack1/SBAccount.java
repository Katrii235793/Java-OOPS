package pack1;

public class SBAccount extends Account {
	
	public double principal;
	public double interest;
	public double rate;
	public int tenure;
	
	
	public SBAccount() {
		super();
	}
	public int getTenure() {
		return tenure;
	}
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	public double getPrincipal() {
		return principal;
	}
	public void setPrincipal(double principal) {
		this.principal = principal;
	}
	public double getInterest() {
		return interest;
	}
	public void setInterest(double interest) {
		this.interest = interest;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	
	public void calculateInterest(ICalculator calculator) {
		
		 interest=calculator.calculateInterest(principal, rate);
		System.out.println(interest+" is the SB Account interest value.");
	}

	

}
