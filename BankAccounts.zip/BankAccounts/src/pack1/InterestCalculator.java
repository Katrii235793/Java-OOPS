package pack1;

public class InterestCalculator implements ICalculator {
	public double calculateInterest(double principal,double rate,int tenure) 
	{
		double interest=(principal*rate*tenure)/100;
		return interest;
	}
	
	public double calculateInterest(double principal,double rate) 
	{
		double interest=(principal*rate*3)/100;
		return interest;
	}
	
	public double calculateEmi(double loanOutStanding,double rate,int tenure) 
	{
		double emi= (loanOutStanding * rate *Math.pow(1+rate,tenure)/Math.pow(1+rate,tenure-1));
		return emi;
	}
	

}
//Math.pow(1+rate,tenure)/Math.pow(1+rate,tenure-1)