/**
 * 
 */
package pack1;

/**
 * @author 235793
 *
 */
public interface Renewable {
	public abstract void autoRenewal(int tenure);

}
