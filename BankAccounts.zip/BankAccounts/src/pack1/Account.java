package pack1;

public class Account {
	public int accountNumber;	
	public String accountHolderName;
	private float balance;
	//public double rate;
	public double interest;
	
	
	

	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	private float getBalance() {
		return balance;
	}
	private void setBalance(float balance) {
		this.balance = balance;
	}


	
	public double getInterest() {
		return interest;
	}
	public void setInterest(double interest) {
		this.interest = interest;
	}
	public void withdrawMoney(float amountToWithdraw) 
	{
		if(amountToWithdraw>balance) {
			System.out.println("Your account has insufficient balance");
			
		}
		
	else {
		balance=balance-amountToWithdraw;
		System.out.println("Your account got deducted of Rs "+amountToWithdraw+".The current balance is Rs "+ balance);
	}
	}
}
	
	
