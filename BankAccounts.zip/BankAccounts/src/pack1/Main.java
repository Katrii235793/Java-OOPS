package pack1;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Account account=new Account();
		//account.withdrawMoney(2000);
		FDAccount fd=new FDAccount();
		LoanAccount la=new LoanAccount();
		SBAccount sb=new SBAccount();
		ICalculator calculator =new InterestCalculator();
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the Account Holder's Details");
		int accountNumber=scan.nextInt();	
	   String accountHolderName=scan.next();
	    float balance=scan.nextFloat();
	    
		
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy"); 
		Date date=null;
	    try {  
	        date = formatter.parse("01/03/2022");  
	        System.out.println("Date is: "+date);  
	    } catch (ParseException e) {e.printStackTrace();}
	    
	    
	    fd.setTenure(12);
		fd.setPrincipal(20000);
		fd.setRate(7);
		fd.setAutoRenewal(false);	    
		fd.setOpenDate(date);
		fd.setMaturityDate();
		fd.autoRenewal(12);

		la.setTenure(5);
		la.setLoanOutStanding(45000);
		la.setRate(14);
		
		
		
		sb.setPrincipal(37000);
		sb.setRate(4);
		
		
		
		fd.calculateInterest(calculator);
		la.calculateInterest();
		sb.calculateInterest(calculator);
		
		

	}

}
