package pack1;

public class LoanAccount extends Account{
	public int tenure;
	public int EMI; 
	public double loanOutStanding;
	public double rate;
	public double loanamount;
	public InterestCalculator ic=new InterestCalculator();
	
	
	
	public LoanAccount() {
		super();
	}

	public int getTenure() {
		return tenure;
	}

	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

	public int getEMI() {
		return EMI;
	}

	public void setEMI(int eMI) {
		EMI = eMI;
	}

	public double getLoanOutStanding() {
		return loanOutStanding;
	}

	public void setLoanOutStanding(double loanOutStanding) {
		this.loanOutStanding = loanOutStanding;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}
//double loanOutStanding,double rate,int tenure
	 
	
	public void calculateInterest() {
		//interest=(EMI*rate*tenure)/100;
		interest=ic.calculateEmi(loanOutStanding, rate, tenure);
		
		
		System.out.println(interest+" is the Loan Account Account interest value.");
	}
	
	

}
