package pack1;

public class CurrentAccount extends Account {
	
	public int overDraftLimit;
	
	

	public CurrentAccount() {
		super();
	}

	public int getOverDraftLimit() {
		return overDraftLimit;
	}

	public void setOverDraftLimit(int overDraftLimit) {
		this.overDraftLimit = overDraftLimit;
	}
	
	public void displayLimit(int overDraftLimit)
	{
	
	      System.out.println(overDraftLimit);
	}
	

}
