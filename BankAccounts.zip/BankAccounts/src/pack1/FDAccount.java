package pack1;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
//import java.util.Calendar;
//import java.util.Date;

public class FDAccount extends Account implements Renewable {

	public int tenure;
	public boolean autoRenewal;
	public double principal;
	public double interest;
	public double rate;
	//public InterestCalculator ic = new InterestCalculator();
	public Date openDate;
	public Date maturityDate;
	
	public FDAccount() {
		super();
	}


	public int getTenure() {
		return tenure;
	}

	public Date getOpenDate() {
		return openDate;
	}

	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}

	public Date getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate() {
		Calendar cal = Calendar.getInstance();
		cal.setTime(openDate);
		cal.add(Calendar.MONTH, tenure);
		this.maturityDate=cal.getTime();
		System.out.println("maturity Date="+this.maturityDate);
	}

	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

	public boolean isAutoRenewal() {
		return autoRenewal;
	}

	public double getPrincipal() {
		return principal;
	}

	public void setPrincipal(double principal) {
		this.principal = principal;
	}

	public double getInterest() {
		return interest;
	}

	public void setInterest(double interest) {
		this.interest = interest;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public void setAutoRenewal(boolean autoRenewal) {
		this.autoRenewal = autoRenewal;
	}

	
	public void calculateInterest(ICalculator calculator) {
		
		 interest=calculator.calculateInterest(principal, rate, tenure);
		System.out.println(interest+" is the FD Account interest value.");
	}

@Override
	public void autoRenewal(int tenure) {
	
	
    LocalDate date = LocalDate.now();
    if(isAutoRenewal()==true) {
    	
    	SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");  
        String strDate = formatter.format(maturityDate); 
        String currDate = formatter.format(new Date());
        Date matdate =null;
        Date mycurrDate=null;
        try {  
	       matdate = formatter.parse(strDate);  
	       mycurrDate = formatter.parse(currDate);
	    } catch (ParseException e) {e.printStackTrace();}
		
    	 if(matdate.compareTo(mycurrDate) == 0) {
             Calendar cal = Calendar.getInstance();
             cal.setTime(maturityDate);
             cal.add(Calendar.MONTH, tenure);

             maturityDate = cal.getTime();
             System.out.println("New maturity date="+maturityDate);
		}
    	 
		
    }else {
		 System.out.println("No autorenewal");
		 
	 }
		

}

}

/*
 * LocalDate current=java.time.LocalDate.now(); // TODO Auto-generated method
 * stub Date ten=Date(int tenure);
 * 
 * if(autoRenewal==true) {
 * 
 * if (autoRenewal(0) && maturityDate.compareTo(LocalDate.now()) <= 0) {
 * maturityDate.setTime(add.(LocalDate.now(),(tenure * 24 * 60 * 60 * 1000)));
 * System.out.println(maturityDate); } }
 * 
 * 
 * Calendar calendar = Calendar.getInstance(); //if(autoRenewal==true) {
 * 
 * System.out.println("Current Date = " + calendar.getTime());
 * calendar.add(Calendar.YEAR, tenure); System.out.println("Updated Date = " +
 * calendar.getTime());
 * 
 * }
 * 
 * //return false; }
 * 
 */
