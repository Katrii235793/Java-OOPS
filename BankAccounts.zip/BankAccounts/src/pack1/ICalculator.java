package pack1;

public interface ICalculator {
	
	public double calculateInterest(double principal,double rate,int tenure);
	
	public double calculateInterest(double principal,double rate);

}
